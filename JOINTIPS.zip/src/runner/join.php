<?php

namespace runner;

use pocketmine\event\player\{PlayerJoinEvent, PlayerQuitEvent,};
use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\Player;


class join extends PluginBase implements Listener {

public function onEnable() {
  $this->getServer()->getPluginManager()->registerEvents ($this, $this);
 }

 public function onJoin (PlayerJoinEvent $event) {
   $player = $event->getPlayer();
   $event->setJoinMessage(false);
   $name = $player->getName();
   $c = count($this->getServer()->getOnlinePlayers());

   if (!($player->hasPlayedBefore())) {
     Server::broadcastMessage("§l§6{$name} §f님이 서버에 §c첫§f 접속 하셨습니다.");
      Server::broadcastMessage("§l§7다들 환영해주세요 !");
   }
   else {
     foreach ( $this->getServer()->getOnlinePlayers() as $player ) {
       $player->sendTip("§6+{$name}§c"."$c명");
     }
   }
 }
 public function onQuit (PlayerQuitEvent $event) {
   $player = $event->getPlayer();
   $event->setJoinMessage(false);
   $name = $player->getName();
   $c = count($this->getServer()->getOnlinePlayers());
    if($player->isOP()) {
     foreach ( $this->getServer()->getOnlinePlayers() as $player ) {
       $player->sendTip('§6-{$name}'.'§c{$c}명');
     }
   }
   if(! $player->isOP()) {
    foreach ( $this->getServer()->getOnlinePlayers() as $player ) {
      $player->sendTip('§6-{$name}'.'§c{$c}명');
    }
  }

}
} ?>
